# Skill-Anything App Bundle

This bundle runs the Skill-Anything browser portal in Docker. The destination machine needs
Docker Desktop (Windows or macOS) or Docker Engine with the Docker Compose plugin (Linux).
It does not need Python installed. The first launch needs an internet connection to download
the base image and Python dependencies.

## Start the app

1. Extract the ZIP.
2. In the extracted `skill-anything-app` folder, copy `.env.example` to `.env`.
3. Open `.env` and set `PORTAL_SESSION_SECRET` to a new, random value. For example, in
   PowerShell:

   ```powershell
   $bytes = New-Object byte[] 48
   $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
   $rng.GetBytes($bytes)
   [Convert]::ToBase64String($bytes)
   ```

   Copy the printed value after `PORTAL_SESSION_SECRET=` in `.env`.
4. Optionally add an OpenAI-compatible provider key to `SKILL_ANYTHING_API_KEY`. Without
   a configured key, generation uses the built-in rule-based fallback.
5. From that folder, run:

   ```powershell
   docker compose up --build -d
   ```
6. Open [http://localhost:8000](http://localhost:8000) and create an account.

To use a different local port, set `PORT=8080` in `.env` and open
`http://localhost:8080`.

## Stop, update, and preserve data

- Stop the app: `docker compose down`
- Start it again: `docker compose up -d`
- Upgrade/rebuild after changing files: `docker compose up --build -d`

Uploaded material, accounts, and learning progress persist in the Docker volume named
`portal-data`. Back up this volume before moving or replacing the installation. Do not use
`docker compose down -v` unless you intend to delete that data.

For an internet-facing deployment, put the app behind HTTPS and set
`PORTAL_SECURE_COOKIES=true` in `.env`. Use a unique session secret and restrict access to
trusted users. The default configuration is intended for local access over HTTP.
