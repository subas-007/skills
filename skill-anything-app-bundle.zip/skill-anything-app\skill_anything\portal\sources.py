"""Extract bounded text from supported portal uploads and external resources."""

from __future__ import annotations

import http.client
import ipaddress
import socket
import ssl
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from urllib.parse import quote, urlsplit

from skill_anything.models import KnowledgeChunk, Section

MAX_SOURCE_CHARS = 250_000
MAX_WEB_BYTES = 5 * 1024 * 1024
MAX_DOCX_XML_BYTES = 10 * 1024 * 1024
SUPPORTED_SUFFIXES = {
    ".pdf",
    ".docx",
    ".md",
    ".markdown",
    ".txt",
    ".text",
    ".rst",
    ".srt",
    ".vtt",
}


def _validate_public_https_url(url: str) -> tuple[str, str]:
    if len(url) > 2048:
        raise ValueError("The URL is too long.")
    parsed = urlsplit(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Use a public HTTPS webpage or a YouTube URL.")
    host = parsed.hostname.rstrip(".").lower()
    try:
        port = parsed.port
    except ValueError as error:
        raise ValueError("The URL has an invalid port.") from error
    if port not in (None, 443):
        raise ValueError("Only standard HTTPS webpages on port 443 are supported.")
    if host in {"localhost", "localhost.localdomain"} or host.endswith(".localhost"):
        raise ValueError("Local and private network URLs are not allowed.")
    try:
        addresses = sorted({
            ipaddress.ip_address(item[4][0])
            for item in socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
        }, key=lambda address: (address.version, int(address)))
    except (OSError, ValueError) as error:
        raise ValueError("The URL host could not be resolved.") from error
    if not addresses or any(not address.is_global for address in addresses):
        raise ValueError("Local and private network URLs are not allowed.")
    try:
        host_header = str(ipaddress.ip_address(host))
    except ValueError:
        host_header = host.encode("idna").decode("ascii")
    return host_header, str(addresses[0])


def _fetch_public_page(url: str) -> str:
    host, pinned_ip = _validate_public_https_url(url)
    parsed = urlsplit(url)
    path = quote(parsed.path or "/", safe="/%:@!$&'()*+,;=-._~")
    if parsed.query:
        path += "?" + quote(parsed.query, safe="=&;%:@!$'()*+,-._~/?")

    class PinnedHTTPSConnection(http.client.HTTPSConnection):
        def connect(self) -> None:
            raw_socket = socket.create_connection(
                (pinned_ip, self.port), timeout=self.timeout, source_address=self.source_address
            )
            try:
                self.sock = self._context.wrap_socket(raw_socket, server_hostname=host)
            except Exception:
                raw_socket.close()
                raise

    connection = PinnedHTTPSConnection(host, timeout=15, context=ssl.create_default_context())
    try:
        connection.request(
            "GET",
            path,
            headers={
                "Accept": "text/html,application/xhtml+xml",
                "Accept-Encoding": "identity",
                "Connection": "close",
                "User-Agent": "Mozilla/5.0 (compatible; SkillAnythingPortal/1.0)",
            },
        )
        response = connection.getresponse()
        if 300 <= response.status < 400:
            raise ValueError("Webpage redirects are not followed. Use the final HTTPS URL.")
        if not 200 <= response.status < 300:
            raise ValueError(f"The webpage returned HTTP {response.status}.")
        if response.headers.get_content_type() not in {
            "text/html",
            "application/xhtml+xml",
        }:
            raise ValueError("The URL does not serve an HTML webpage.")
        if response.headers.get("content-encoding", "identity").lower() != "identity":
            raise ValueError("The webpage uses an unsupported content encoding.")
        content_length = response.headers.get("content-length")
        if content_length and int(content_length) > MAX_WEB_BYTES:
            raise ValueError("The webpage is larger than the 5 MB processing limit.")
        body = bytearray()
        while chunk := response.read(min(64 * 1024, MAX_WEB_BYTES + 1 - len(body))):
            body.extend(chunk)
            if len(body) > MAX_WEB_BYTES:
                raise ValueError("The webpage is larger than the 5 MB processing limit.")
        return bytes(body).decode(
            response.headers.get_content_charset() or "utf-8", errors="replace"
        )
    finally:
        connection.close()


def sections_from_url(url: str) -> tuple[str, str, list[Section]]:
    from skill_anything.parsers.video_parser import VideoParser

    if VideoParser._is_youtube_url(url):
        sections = VideoParser().parse_sections(url)
        return url, "video", sections

    from skill_anything.parsers.web_parser import WebParser

    parser = WebParser()
    html = _fetch_public_page(url)
    title, text = parser._extract_content(html)
    sections = parser._build_sections(text, title, url)
    return title or url, "webpage", sections


def sections_from_file(path: Path, suffix: str) -> tuple[str, str, list[Section]]:
    suffix = suffix.lower()
    if suffix not in SUPPORTED_SUFFIXES:
        raise ValueError(
            "Supported uploads are PDF, DOCX, Markdown, plain text, RST, and SRT/VTT transcripts."
        )

    if suffix == ".pdf":
        from skill_anything.parsers.pdf_parser import PDFParser

        sections = PDFParser().parse_sections(str(path))
        source_type = "pdf"
    elif suffix == ".docx":
        sections = _sections_from_docx(path)
        source_type = "word document"
    elif suffix in {".srt", ".vtt"}:
        from skill_anything.parsers.video_parser import VideoParser

        sections = VideoParser().parse_sections(str(path))
        source_type = "video transcript"
    else:
        from skill_anything.parsers.text_parser import TextParser

        sections = TextParser().parse_sections(str(path))
        source_type = "text"
    return path.stem, source_type, sections


def _sections_from_docx(path: Path) -> list[Section]:
    try:
        with zipfile.ZipFile(path) as document:
            document_xml = document.getinfo("word/document.xml")
            if document_xml.file_size > MAX_DOCX_XML_BYTES:
                raise ValueError("The Word document is too large to process.")
            xml_content = document.read(document_xml)
        root = ET.fromstring(xml_content)
    except (OSError, KeyError, zipfile.BadZipFile, ET.ParseError) as error:
        raise ValueError("The DOCX file is invalid or could not be read.") from error

    paragraphs = []
    for paragraph in root.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p"):
        text = "".join(
            item.text or ""
            for item in paragraph.iter(
                "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t"
            )
        ).strip()
        if text:
            paragraphs.append(text)
    if not paragraphs:
        raise ValueError("No readable text was found in that Word document.")
    text = "\n\n".join(paragraphs)
    return [
        Section(
            id="sec-001",
            title=path.stem,
            chunks=[
                KnowledgeChunk(
                    content=text,
                    section=path.stem,
                    section_id="sec-001",
                )
            ],
        )
    ]


def flatten_sections(sections: list[Section]) -> str:
    blocks = [
        f"## {section.title}\n\n{section.content.strip()}"
        for section in sections
        if section.content.strip()
    ]
    content = "\n\n".join(blocks).strip()
    if not content:
        raise ValueError("No readable text was found in that source.")
    if len(content) > MAX_SOURCE_CHARS:
        raise ValueError(
            f"The extracted source is over the {MAX_SOURCE_CHARS:,}-character limit. "
            "Split it into smaller files and upload them separately."
        )
    return content
