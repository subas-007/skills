"""Grounded question-and-answer helpers for the portal."""

from __future__ import annotations

from skill_anything.llm import chat


class QnAError(RuntimeError):
    """The configured model failed to answer a source-grounded question."""


def answer_question(source_content: str, question: str) -> str:
    prompt = f"""Answer the learner's question using only the study material below.
If the material does not contain enough information, say so plainly. Do not invent facts.

Study material:
{source_content[:30_000]}

Learner question:
{question}
"""
    try:
        answer = chat(
            [{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=1_500,
        )
    except Exception as error:
        raise QnAError("The configured model could not answer this question.") from error
    if not answer:
        raise QnAError("The configured model returned an empty answer.")
    return answer
