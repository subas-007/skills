"""FastAPI application for the Skill-Anything browser portal."""

from __future__ import annotations

import html
import json
import logging
import os
import re
import tempfile
import uuid
from contextlib import asynccontextmanager
from datetime import timedelta
from pathlib import Path
from typing import Literal
from urllib.parse import quote

from dotenv import load_dotenv
from fastapi import BackgroundTasks, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from starlette.concurrency import run_in_threadpool

from skill_anything.llm import is_available
from skill_anything.portal.auth import (
    SESSION_COOKIE,
    client_key,
    create_session,
    current_session,
    hash_password,
    invalidate_session,
    timestamp,
    utc_now,
    verify_password,
)
from skill_anything.portal.database import connect, data_directory, initialize_database
from skill_anything.portal.qna import QnAError, answer_question
from skill_anything.portal.questions import (
    QuestionGenerationError,
    generate_questions,
    public_questions,
)
from skill_anything.portal.sources import (
    SUPPORTED_SUFFIXES,
    flatten_sections,
    sections_from_file,
    sections_from_url,
)

log = logging.getLogger(__name__)
STATIC_DIR = Path(__file__).parent / "static"
MAX_UPLOAD_BYTES = 20 * 1024 * 1024
USERNAME_PATTERN = re.compile(r"^[A-Za-z0-9_-]{3,32}$")
for _env_file in (Path.cwd() / ".env", Path(__file__).resolve().parents[2] / ".env"):
    if _env_file.is_file():
        load_dotenv(_env_file, override=False)
        break


class Credentials(BaseModel):
    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=12, max_length=256)


class QuizRequest(BaseModel):
    mode: Literal["learning", "exam"]
    count: int = Field(default=10, ge=1, le=30)
    sample_questions: str = Field(default="", max_length=4000)
    question_types: list[
        Literal["knowledge", "comprehension", "application", "analysis"]
    ] = Field(default_factory=lambda: ["knowledge"], min_length=1, max_length=4)
    difficulty: Literal["low", "medium", "hard"] = "medium"
    confirm_external_processing: bool


class QnARequest(BaseModel):
    source_id: str
    question: str = Field(min_length=1, max_length=2000)
    conversation_id: str | None = None


class UserStatusUpdate(BaseModel):
    is_active: bool


class LearningAnswer(BaseModel):
    question_index: int = Field(ge=0)
    option_index: int = Field(ge=0, le=3)


class ExamSubmission(BaseModel):
    answers: list[int] = Field(min_length=1, max_length=30)


def create_app() -> FastAPI:
    @asynccontextmanager
    async def lifespan(_application: FastAPI):
        initialize_database()
        with connect() as connection:
            connection.execute(
                """
                UPDATE generation_jobs SET status = 'failed',
                    message = 'Generation stopped because the server restarted',
                    error = 'Generation was interrupted. Please try again.',
                    updated_at = ?
                WHERE status IN ('queued', 'running')
                """,
                (timestamp(),),
            )
        yield

    application = FastAPI(
        title="Skill-Anything Portal",
        docs_url=None,
        redoc_url=None,
        lifespan=lifespan,
    )
    application.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @application.middleware("http")
    async def _security_headers(request: Request, call_next):
        try:
            response = await call_next(request)
        except Exception:
            _write_log(
                action=f"{request.method} {request.url.path}",
                status="500",
                details="Unhandled request exception",
            )
            raise
        response.headers["X-Content-Type-Options"] = "nosniff"
        is_document_preview = request.url.path.endswith("/preview")
        response.headers["X-Frame-Options"] = "SAMEORIGIN" if is_document_preview else "DENY"
        response.headers["Referrer-Policy"] = "same-origin"
        frame_ancestors = "'self'" if is_document_preview else "'none'"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; style-src 'self'; script-src 'self'; "
            "img-src 'self' data:; connect-src 'self'; "
            f"base-uri 'self'; form-action 'self'; object-src 'none'; frame-ancestors {frame_ancestors}"
        )
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
            _write_log(
                action=f"{request.method} {request.url.path}",
                status=str(response.status_code),
                details=(
                    "HTTP request"
                    if response.status_code < 400
                    else f"HTTP error response {response.status_code}"
                ),
            )
        return response

    @application.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    @application.get("/api/config")
    def config() -> dict:
        return {
            "model_configured": is_available(),
            "model": os.getenv("SKILL_ANYTHING_MODEL", "gpt-6-luna"),
            "max_upload_mb": MAX_UPLOAD_BYTES // (1024 * 1024),
        }

    @application.post("/api/auth/register")
    def register(payload: Credentials, request: Request) -> JSONResponse:
        _ensure_session_secret()
        if not USERNAME_PATTERN.fullmatch(payload.username):
            raise HTTPException(
                status_code=422,
                detail=(
                    "Usernames may contain 3–32 letters, numbers, underscores, or hyphens."
                ),
            )
        ip_key = client_key(request)
        _rate_limit("register", ip_key, limit=5, window=timedelta(days=1))
        try:
            with connect() as connection:
                cursor = connection.execute(
                    "INSERT INTO users(username, password_hash, created_at) VALUES (?, ?, ?)",
                    (payload.username, hash_password(payload.password), timestamp()),
                )
                user_id = int(cursor.lastrowid)
        except Exception as error:
            if "UNIQUE constraint failed" in str(error):
                raise HTTPException(
                    status_code=409, detail="That username is already in use."
                ) from error
            raise
        _write_log(
            action="auth.register",
            status="success",
            user_id=user_id,
            username=payload.username,
        )
        return _login_response(user_id, payload.username)

    @application.post("/api/auth/login")
    def login(payload: Credentials, request: Request) -> JSONResponse:
        _ensure_session_secret()
        ip_key = client_key(request)
        if _event_count("login-failure", ip_key, timedelta(minutes=15)) >= 8:
            raise HTTPException(
                status_code=429,
                detail="Too many sign-in attempts. Please wait 15 minutes and try again.",
            )
        with connect() as connection:
            user = connection.execute(
                "SELECT id, username, password_hash, is_active FROM users WHERE username = ?",
                (payload.username,),
            ).fetchone()
            if (
                user is None
                or not user["is_active"]
                or not verify_password(payload.password, user["password_hash"])
            ):
                _record_event("login-failure", ip_key)
                raise HTTPException(status_code=401, detail="Invalid username or password.")
            _clear_events("login-failure", ip_key)
            _write_log(
                action="auth.login",
                status="success",
                user_id=int(user["id"]),
                username=user["username"],
            )
            return _login_response(int(user["id"]), user["username"])

    @application.get("/api/me")
    def me(request: Request) -> dict:
        try:
            session = current_session(request)
        except HTTPException as error:
            if error.status_code != 401:
                raise
            return {"authenticated": False}
        return {
            "authenticated": True,
            "username": session["username"],
            "csrf_token": session["csrf_token"],
            "is_admin": _is_admin_username(session["username"]),
        }

    @application.post("/api/auth/logout")
    def logout(request: Request) -> JSONResponse:
        user = current_session(request, require_csrf=True)
        invalidate_session(request)
        _write_log(
            action="auth.logout",
            status="success",
            user_id=user["user_id"],
            username=user["username"],
        )
        response = JSONResponse({"ok": True})
        _clear_session_cookie(response)
        return response

    @application.get("/api/sources")
    def list_sources(request: Request) -> list[dict]:
        user = _require_learner(request)
        with connect() as connection:
            rows = connection.execute(
                "SELECT id, title, source_type, file_name, created_at FROM sources "
                "WHERE user_id = ? ORDER BY created_at DESC",
                (user["user_id"],),
            ).fetchall()
        return [
            {
                **dict(row),
                "preview_available": Path(row["file_name"] or "").suffix.lower()
                in {".pdf", ".docx"},
            }
            for row in rows
        ]

    @application.post("/api/sources")
    @application.post("/api/sources/upload")
    async def create_source(
        request: Request,
        file: UploadFile | None = File(default=None),
        url: str = Form(default=""),
    ) -> dict:
        user = _require_learner(request, require_csrf=True)
        if bool(file) == bool(url.strip()):
            raise HTTPException(status_code=422, detail="Upload one file or enter one URL.")
        try:
            file_name = None
            uploaded_data = None
            if file is not None:
                filename = Path((file.filename or "").replace("\\", "/")).name
                suffix = Path(filename).suffix.lower()
                if suffix not in SUPPORTED_SUFFIXES:
                    raise ValueError(
                        "Supported uploads are PDF, DOCX, Markdown, plain text, RST, and "
                        "SRT/VTT transcripts. Raw video transcription is not available yet."
                    )
                data_directory().mkdir(parents=True, exist_ok=True)
                temp_path: Path | None = None
                try:
                    with tempfile.NamedTemporaryFile(
                        prefix="upload-", suffix=suffix, dir=data_directory(), delete=False
                    ) as temporary:
                        temp_path = Path(temporary.name)
                        size = 0
                        while chunk := await file.read(1024 * 1024):
                            size += len(chunk)
                            if size > MAX_UPLOAD_BYTES:
                                raise HTTPException(
                                    status_code=413,
                                    detail="Uploads are limited to 20 MB.",
                                )
                            temporary.write(chunk)
                    title, source_type, sections = await run_in_threadpool(
                        sections_from_file, temp_path, suffix
                    )
                    title = Path(filename).stem or title
                    file_name = filename
                    if suffix in {".pdf", ".docx"}:
                        uploaded_data = temp_path.read_bytes()
                finally:
                    await file.close()
                    if temp_path is not None:
                        temp_path.unlink(missing_ok=True)
            else:
                title, source_type, sections = await run_in_threadpool(
                    sections_from_url, url.strip()
                )
            content = flatten_sections(sections)
        except HTTPException:
            raise
        except (ValueError, FileNotFoundError, ImportError) as error:
            _write_log(
                action="source.extract",
                status="failed",
                user_id=user["user_id"],
                username=user["username"],
                details=type(error).__name__,
            )
            raise HTTPException(status_code=422, detail=str(error)) from error
        except Exception as error:
            log.exception("Source extraction failed")
            _write_log(
                action="source.extract",
                status="failed",
                user_id=user["user_id"],
                username=user["username"],
                details=type(error).__name__,
            )
            raise HTTPException(
                status_code=422,
                detail="Could not extract readable text from that source.",
            ) from error

        source_id = str(uuid.uuid4())
        safe_title = Path(title).name[:160] or "Study material"
        with connect() as connection:
            connection.execute(
                """
                INSERT INTO sources(
                    id, user_id, title, source_type, content, file_name, file_data, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    source_id,
                    user["user_id"],
                    safe_title,
                    source_type,
                    content,
                    file_name,
                    uploaded_data,
                    timestamp(),
                ),
            )
        _write_log(
            action="source.created",
            status="success",
            user_id=user["user_id"],
            username=user["username"],
            details=f"type={source_type} characters={len(content)}",
        )
        return {
            "id": source_id,
            "title": safe_title,
            "source_type": source_type,
            "characters": len(content),
        }

    @application.post("/api/sources/from-url")
    async def create_source_from_url(request: Request, url: str = Form(...)) -> dict:
        return await create_source(request=request, file=None, url=url)

    @application.delete("/api/sources/{source_id}")
    def delete_source(source_id: str, request: Request) -> dict:
        user = _require_learner(request, require_csrf=True)
        with connect() as connection:
            result = connection.execute(
                "DELETE FROM sources WHERE id = ? AND user_id = ?",
                (source_id, user["user_id"]),
            )
        if result.rowcount == 0:
            raise HTTPException(status_code=404, detail="Source not found.")
        _write_log(
            action="source.deleted",
            status="success",
            user_id=user["user_id"],
            username=user["username"],
            details=f"source_id={source_id}",
        )
        return {"ok": True}

    @application.get("/api/sources/{source_id}/preview")
    def preview_source(source_id: str, request: Request) -> Response:
        user = _require_learner(request)
        source = _owned_source(source_id, user["user_id"])
        filename = source["file_name"] or ""
        suffix = Path(filename).suffix.lower()
        if suffix == ".pdf" and source["file_data"] is not None:
            safe_filename = Path(filename).name.replace('"', "").replace("\r", "").replace("\n", "")
            return Response(
                content=bytes(source["file_data"]),
                media_type="application/pdf",
                headers={
                    "Content-Disposition": f"inline; filename*=UTF-8''{quote(safe_filename)}",
                    "Cache-Control": "private, no-store",
                },
            )
        if suffix == ".docx" and source["content"]:
            preview = (
                "<!doctype html><html lang=\"en\"><meta charset=\"utf-8\">"
                f"<title>{html.escape(source['title'])}</title>"
                f"<body><h1>{html.escape(source['title'])}</h1>"
                f"<pre>{html.escape(source['content'])}</pre></body></html>"
            )
            return Response(
                content=preview,
                media_type="text/html",
                headers={"Cache-Control": "private, no-store"},
            )
        raise HTTPException(status_code=404, detail="A preview is not available for this resource.")

    @application.post("/api/sources/{source_id}/quizzes")
    def start_quiz(source_id: str, payload: QuizRequest, request: Request) -> dict:
        user = _require_learner(request, require_csrf=True)
        source = _validate_generation_request(source_id, payload, user)
        try:
            questions = generate_questions(
                source["content"],
                payload.count,
                payload.sample_questions,
                question_types=payload.question_types,
                difficulty=payload.difficulty,
            )
        except QuestionGenerationError as error:
            _write_log(
                action="quiz.generation",
                status="failed",
                user_id=user["user_id"],
                username=user["username"],
                details=error.diagnostic or type(error).__name__,
            )
            raise HTTPException(status_code=502, detail=str(error)) from error

        quiz_id = str(uuid.uuid4())
        _store_quiz(quiz_id, user["user_id"], source_id, payload, questions)
        _write_log(
            action="quiz.generation",
            status="success",
            user_id=user["user_id"],
            username=user["username"],
            details=f"quiz_id={quiz_id} count={len(questions)} difficulty={payload.difficulty}",
        )
        return _quiz_view(
            quiz_id,
            payload.mode,
            questions,
            0,
            False,
            None,
            payload.difficulty,
            payload.question_types,
        )

    @application.post("/api/sources/{source_id}/quiz-jobs", status_code=202)
    def create_quiz_job(
        source_id: str,
        payload: QuizRequest,
        request: Request,
        background_tasks: BackgroundTasks,
    ) -> dict:
        user = _require_learner(request, require_csrf=True)
        source = _validate_generation_request(source_id, payload, user)
        job_id = str(uuid.uuid4())
        now = timestamp()
        dump_json = getattr(payload, "model_dump_json", None)
        request_json = dump_json() if dump_json else payload.json()
        with connect() as connection:
            connection.execute(
                """
                INSERT INTO generation_jobs(
                    id, user_id, source_id, status, progress, message, request_json,
                    created_at, updated_at
                ) VALUES (?, ?, ?, 'queued', 0, ?, ?, ?, ?)
                """,
                (
                    job_id,
                    user["user_id"],
                    source_id,
                    "Waiting to generate questions",
                    request_json,
                    now,
                    now,
                ),
            )
        _write_log(
            action="quiz.generation.queued",
            status="accepted",
            user_id=user["user_id"],
            username=user["username"],
            details=f"job_id={job_id}",
        )
        background_tasks.add_task(
            _run_generation_job,
            job_id,
            user["user_id"],
            user["username"],
            source_id,
            source["content"],
            request_json,
        )
        return {"job_id": job_id, "status": "queued", "progress": 0}

    @application.get("/api/quiz-jobs/{job_id}")
    def get_quiz_job(job_id: str, request: Request) -> dict:
        user = _require_learner(request)
        with connect() as connection:
            row = connection.execute(
                "SELECT * FROM generation_jobs WHERE id = ? AND user_id = ?",
                (job_id, user["user_id"]),
            ).fetchone()
        if row is None:
            raise HTTPException(status_code=404, detail="Generation job not found.")
        result = {
            "job_id": row["id"],
            "status": row["status"],
            "progress": row["progress"],
            "message": row["message"],
        }
        if row["status"] == "completed" and row["quiz_id"]:
            quiz = _owned_quiz(row["quiz_id"], user["user_id"])
            attempt = _attempt_for_quiz(row["quiz_id"])
            questions = json.loads(quiz["questions_json"])
            result["quiz"] = _quiz_view(
                quiz["id"],
                quiz["mode"],
                questions,
                quiz["current_index"],
                bool(quiz["completed"]),
                quiz["score_percent"],
                attempt["difficulty"],
                json.loads(attempt["question_types_json"]),
            )
        elif row["status"] == "failed":
            result["error"] = row["error"] or "Question generation failed. Please try again."
        return result

    @application.get("/api/quizzes/{quiz_id}")
    def get_quiz(quiz_id: str, request: Request) -> dict:
        user = _require_learner(request)
        quiz = _owned_quiz(quiz_id, user["user_id"])
        attempt = _attempt_for_quiz(quiz_id)
        return _quiz_view(
            quiz["id"],
            quiz["mode"],
            json.loads(quiz["questions_json"]),
            quiz["current_index"],
            bool(quiz["completed"]),
            quiz["score_percent"],
            attempt["difficulty"],
            json.loads(attempt["question_types_json"]),
        )

    @application.get("/api/history")
    def list_attempt_history(request: Request) -> list[dict]:
        user = _require_learner(request)
        with connect() as connection:
            rows = connection.execute(
                """
                SELECT a.quiz_id, a.mode, a.difficulty, a.question_types_json,
                       a.total_questions, a.status, a.score_percent, a.started_at,
                       a.completed_at, s.title AS source_title
                FROM quiz_attempts a
                JOIN sources s ON s.id = a.source_id
                WHERE a.user_id = ?
                ORDER BY a.started_at DESC LIMIT 200
                """,
                (user["user_id"],),
            ).fetchall()
        return [
            {
                "quiz_id": row["quiz_id"],
                "mode": row["mode"],
                "difficulty": row["difficulty"],
                "question_types": json.loads(row["question_types_json"]),
                "total_questions": row["total_questions"],
                "status": row["status"],
                "score_percent": row["score_percent"],
                "started_at": row["started_at"],
                "completed_at": row["completed_at"],
                "source_title": row["source_title"],
            }
            for row in rows
        ]

    @application.post("/api/quizzes/{quiz_id}/answer")
    def answer_learning(
        quiz_id: str, payload: LearningAnswer, request: Request
    ) -> dict:
        user = _require_learner(request, require_csrf=True)
        quiz = _owned_quiz(quiz_id, user["user_id"])
        if quiz["mode"] != "learning":
            raise HTTPException(status_code=400, detail="Use exam submission for exam mode.")
        if quiz["completed"]:
            raise HTTPException(status_code=409, detail="This learning quiz is already complete.")
        if payload.question_index != quiz["current_index"]:
            raise HTTPException(status_code=409, detail="Answer the current question first.")

        questions = json.loads(quiz["questions_json"])
        question = questions[payload.question_index]
        answers = json.loads(quiz["answers_json"])
        answers.append(payload.option_index)
        next_index = payload.question_index + 1
        completed = next_index == len(questions)
        correct_count = sum(
            answer == item["correct_index"] for answer, item in zip(answers, questions)
        )
        score = round(100 * correct_count / len(questions)) if completed else None
        with connect() as connection:
            updated = connection.execute(
                """
                UPDATE quizzes
                SET answers_json = ?, current_index = ?, completed = ?, score_percent = ?
                WHERE id = ? AND user_id = ? AND current_index = ? AND completed = 0
                """,
                (
                    json.dumps(answers),
                    next_index,
                    int(completed),
                    score,
                    quiz_id,
                    user["user_id"],
                    payload.question_index,
                ),
            ).rowcount
            if updated == 1 and completed:
                connection.execute(
                    """
                    UPDATE quiz_attempts
                    SET status = 'completed', score_percent = ?, completed_at = ?
                    WHERE quiz_id = ? AND user_id = ?
                    """,
                    (score, timestamp(), quiz_id, user["user_id"]),
                )
        if updated != 1:
            raise HTTPException(status_code=409, detail="This question was already answered.")
        _write_log(
            action="quiz.answer",
            status="success",
            user_id=user["user_id"],
            username=user["username"],
            details=f"quiz_id={quiz_id} question={payload.question_index + 1}",
        )
        feedback = {
            "correct": payload.option_index == question["correct_index"],
            "correct_index": question["correct_index"],
            "explanation": question["explanation"],
            "option_explanations": question["option_explanations"],
            "evidence": question["evidence"],
        }
        return {
            "feedback": feedback,
            "completed": completed,
            "score_percent": score,
            "next_index": next_index,
        }

    @application.post("/api/quizzes/{quiz_id}/submit")
    def submit_exam(
        quiz_id: str, payload: ExamSubmission, request: Request
    ) -> dict:
        user = _require_learner(request, require_csrf=True)
        quiz = _owned_quiz(quiz_id, user["user_id"])
        if quiz["mode"] != "exam":
            raise HTTPException(status_code=400, detail="Submit an exam-mode quiz.")
        if quiz["completed"]:
            raise HTTPException(
                status_code=409,
                detail=f"This exam is already complete. Score: {quiz['score_percent']}%.",
            )
        questions = json.loads(quiz["questions_json"])
        if len(payload.answers) != len(questions) or any(
            answer not in range(4) for answer in payload.answers
        ):
            raise HTTPException(
                status_code=422,
                detail=f"Answer all {len(questions)} questions before submitting.",
            )
        correct_count = sum(
            answer == item["correct_index"]
            for answer, item in zip(payload.answers, questions)
        )
        score = round(100 * correct_count / len(questions))
        with connect() as connection:
            updated = connection.execute(
                """
                UPDATE quizzes
                SET answers_json = ?, current_index = ?, completed = 1, score_percent = ?
                WHERE id = ? AND user_id = ? AND completed = 0
                """,
                (
                    json.dumps(payload.answers),
                    len(questions),
                    score,
                    quiz_id,
                    user["user_id"],
                ),
            ).rowcount
            if updated == 1:
                connection.execute(
                    """
                    UPDATE quiz_attempts
                    SET status = 'completed', score_percent = ?, completed_at = ?
                    WHERE quiz_id = ? AND user_id = ?
                    """,
                    (score, timestamp(), quiz_id, user["user_id"]),
                )
        if updated != 1:
            raise HTTPException(status_code=409, detail="This exam was already submitted.")
        _write_log(
            action="quiz.submit",
            status="success",
            user_id=user["user_id"],
            username=user["username"],
            details=f"quiz_id={quiz_id} score={score}",
        )
        return {"completed": True, "score_percent": score, "total": len(questions)}

    @application.get("/api/qna")
    def list_qna_conversations(request: Request) -> list[dict]:
        user = _require_learner(request)
        with connect() as connection:
            rows = connection.execute(
                """
                SELECT c.id, c.source_id, c.title, c.created_at, c.updated_at,
                       s.title AS source_title
                FROM qna_conversations c JOIN sources s ON s.id = c.source_id
                WHERE c.user_id = ? ORDER BY c.updated_at DESC LIMIT 100
                """,
                (user["user_id"],),
            ).fetchall()
        return [dict(row) for row in rows]

    @application.get("/api/qna/{conversation_id}")
    def get_qna_conversation(conversation_id: str, request: Request) -> dict:
        user = _require_learner(request)
        with connect() as connection:
            conversation = connection.execute(
                "SELECT id, source_id, title FROM qna_conversations "
                "WHERE id = ? AND user_id = ?",
                (conversation_id, user["user_id"]),
            ).fetchone()
            if conversation is None:
                raise HTTPException(status_code=404, detail="Q&A conversation not found.")
            messages = connection.execute(
                "SELECT role, content, created_at FROM qna_messages "
                "WHERE conversation_id = ? ORDER BY id",
                (conversation_id,),
            ).fetchall()
        return {"conversation": dict(conversation), "messages": [dict(row) for row in messages]}

    @application.post("/api/qna")
    def ask_qna(payload: QnARequest, request: Request) -> dict:
        user = _require_learner(request, require_csrf=True)
        source = _owned_source(payload.source_id, user["user_id"])
        if not is_available():
            raise HTTPException(status_code=503, detail="The model is not configured.")
        conversation_id = payload.conversation_id or str(uuid.uuid4())
        with connect() as connection:
            conversation = connection.execute(
                "SELECT id FROM qna_conversations WHERE id = ? AND user_id = ?",
                (conversation_id, user["user_id"]),
            ).fetchone()
            if payload.conversation_id and conversation is None:
                raise HTTPException(status_code=404, detail="Q&A conversation not found.")
            if conversation is None:
                now = timestamp()
                connection.execute(
                    """
                    INSERT INTO qna_conversations(
                        id, user_id, source_id, title, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        conversation_id,
                        user["user_id"],
                        source["id"],
                        payload.question[:120],
                        now,
                        now,
                    ),
                )
            elif payload.conversation_id:
                existing = connection.execute(
                    "SELECT source_id FROM qna_conversations WHERE id = ?",
                    (conversation_id,),
                ).fetchone()
                if existing["source_id"] != payload.source_id:
                    raise HTTPException(
                        status_code=400,
                        detail="Select the source associated with this conversation.",
                    )
            connection.execute(
                "INSERT INTO qna_messages(conversation_id, role, content, created_at) "
                "VALUES (?, 'user', ?, ?)",
                (conversation_id, payload.question, timestamp()),
            )
        try:
            answer = answer_question(source["content"], payload.question)
        except QnAError as error:
            _write_log(
                action="qna.answer",
                status="failed",
                user_id=user["user_id"],
                username=user["username"],
                details=type(error).__name__,
            )
            raise HTTPException(status_code=502, detail=str(error)) from error
        with connect() as connection:
            connection.execute(
                "INSERT INTO qna_messages(conversation_id, role, content, created_at) "
                "VALUES (?, 'assistant', ?, ?)",
                (conversation_id, answer, timestamp()),
            )
            connection.execute(
                "UPDATE qna_conversations SET updated_at = ? WHERE id = ? AND user_id = ?",
                (timestamp(), conversation_id, user["user_id"]),
            )
        _write_log(
            action="qna.answer",
            status="success",
            user_id=user["user_id"],
            username=user["username"],
            details=f"conversation_id={conversation_id}",
        )
        return {"conversation_id": conversation_id, "answer": answer}

    @application.get("/api/admin/summary")
    def admin_summary(request: Request) -> dict:
        _require_admin(request)
        with connect() as connection:
            summary = connection.execute(
                """
                SELECT (SELECT COUNT(*) FROM users) AS users,
                       (SELECT COUNT(*) FROM sources) AS sources,
                       (SELECT COUNT(*) FROM quiz_attempts) AS attempts,
                       (SELECT COUNT(*) FROM quiz_attempts WHERE status = 'completed')
                           AS completed_attempts,
                       (SELECT ROUND(AVG(score_percent), 1) FROM quiz_attempts
                        WHERE status = 'completed') AS average_score
                """
            ).fetchone()
        return dict(summary)

    @application.get("/api/admin/users")
    def admin_users(request: Request) -> list[dict]:
        _require_admin(request)
        with connect() as connection:
            rows = connection.execute(
                """
                SELECT u.id, u.username, u.is_active, u.created_at,
                       COUNT(DISTINCT s.id) AS source_count,
                       COUNT(DISTINCT a.quiz_id) AS attempt_count,
                       ROUND(AVG(CASE WHEN a.status = 'completed'
                                      THEN a.score_percent END), 1) AS average_score
                FROM users u
                LEFT JOIN sources s ON s.user_id = u.id
                LEFT JOIN quiz_attempts a ON a.user_id = u.id
                GROUP BY u.id ORDER BY u.created_at DESC
                """
            ).fetchall()
        return [
            {
                **dict(row),
                "role": "Admin" if _is_admin_username(row["username"]) else "User",
            }
            for row in rows
        ]

    @application.get("/api/admin/users/{user_id}/attempts")
    def admin_user_attempts(user_id: int, request: Request) -> list[dict]:
        _require_admin(request)
        with connect() as connection:
            rows = connection.execute(
                """
                SELECT a.quiz_id, a.mode, a.difficulty, a.question_types_json,
                       a.total_questions, a.status, a.score_percent, a.started_at,
                       a.completed_at, s.title AS source_title
                FROM quiz_attempts a JOIN sources s ON s.id = a.source_id
                WHERE a.user_id = ? ORDER BY a.started_at DESC LIMIT 200
                """,
                (user_id,),
            ).fetchall()
        return [
            {
                "quiz_id": row["quiz_id"],
                "mode": row["mode"],
                "difficulty": row["difficulty"],
                "question_types": json.loads(row["question_types_json"]),
                "total_questions": row["total_questions"],
                "status": row["status"],
                "score_percent": row["score_percent"],
                "started_at": row["started_at"],
                "completed_at": row["completed_at"],
                "source_title": row["source_title"],
            }
            for row in rows
        ]

    @application.patch("/api/admin/users/{user_id}")
    def admin_update_user(
        user_id: int, payload: UserStatusUpdate, request: Request
    ) -> dict:
        admin = _require_admin(request, require_csrf=True)
        if user_id == admin["user_id"] and not payload.is_active:
            raise HTTPException(status_code=400, detail="You cannot disable your own account.")
        with connect() as connection:
            result = connection.execute(
                "UPDATE users SET is_active = ? WHERE id = ?",
                (int(payload.is_active), user_id),
            )
        if result.rowcount == 0:
            raise HTTPException(status_code=404, detail="User not found.")
        _write_log(
            action="admin.user_status",
            status="success",
            user_id=admin["user_id"],
            username=admin["username"],
            details=f"target_user_id={user_id} active={payload.is_active}",
        )
        return {"ok": True, "is_active": payload.is_active}

    @application.get("/api/admin/sources")
    def admin_sources(request: Request) -> list[dict]:
        _require_admin(request)
        with connect() as connection:
            rows = connection.execute(
                """
                SELECT s.id, s.title, s.source_type, s.created_at,
                       u.id AS user_id, u.username,
                       LENGTH(s.content) AS characters
                FROM sources s JOIN users u ON u.id = s.user_id
                ORDER BY s.created_at DESC LIMIT 500
                """
            ).fetchall()
        return [dict(row) for row in rows]

    @application.delete("/api/admin/sources/{source_id}")
    def admin_delete_source(source_id: str, request: Request) -> dict:
        admin = _require_admin(request, require_csrf=True)
        with connect() as connection:
            result = connection.execute("DELETE FROM sources WHERE id = ?", (source_id,))
        if result.rowcount == 0:
            raise HTTPException(status_code=404, detail="Source not found.")
        _write_log(
            action="admin.source_deleted",
            status="success",
            user_id=admin["user_id"],
            username=admin["username"],
            details=f"source_id={source_id}",
        )
        return {"ok": True}

    @application.get("/api/admin/logs")
    def admin_logs(request: Request, limit: int = 200) -> list[dict]:
        _require_admin(request)
        bounded_limit = min(max(limit, 1), 500)
        with connect() as connection:
            rows = connection.execute(
                "SELECT id, username, action, status, details, created_at "
                "FROM portal_logs ORDER BY id DESC LIMIT ?",
                (bounded_limit,),
            ).fetchall()
        return [dict(row) for row in rows]

    return application


app = create_app()


def _ensure_session_secret() -> None:
    if len(os.getenv("PORTAL_SESSION_SECRET", "")) < 32:
        raise HTTPException(
            status_code=503,
            detail=(
                "Set PORTAL_SESSION_SECRET to a persistent random value of at least "
                "32 characters."
            ),
        )


def _is_admin_username(username: str) -> bool:
    admins = {
        item.strip().casefold()
        for item in os.getenv("PORTAL_ADMIN_USERNAMES", "").split(",")
        if item.strip()
    }
    return username.casefold() in admins


def _require_admin(request: Request, *, require_csrf: bool = False) -> dict:
    user = current_session(request, require_csrf=require_csrf)
    if not _is_admin_username(user["username"]):
        raise HTTPException(status_code=403, detail="Administrator access is required.")
    return user


def _require_learner(request: Request, *, require_csrf: bool = False) -> dict:
    user = current_session(request, require_csrf=require_csrf)
    if _is_admin_username(user["username"]):
        raise HTTPException(
            status_code=403,
            detail="This feature is available to learner accounts, not administrators.",
        )
    return user


def _write_log(
    *,
    action: str,
    status: str,
    user_id: int | None = None,
    username: str | None = None,
    details: str = "",
) -> None:
    with connect() as connection:
        connection.execute(
            """
            INSERT INTO portal_logs(user_id, username, action, status, details, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (user_id, username, action[:120], status[:40], details[:500], timestamp()),
        )


def _validate_generation_request(source_id: str, payload: QuizRequest, user: dict):
    if not payload.confirm_external_processing:
        raise HTTPException(
            status_code=400,
            detail=(
                "Confirm that the source text and sample questions may be sent to "
                "the configured model provider."
            ),
        )
    if not is_available():
        raise HTTPException(
            status_code=503,
            detail="Set SKILL_ANYTHING_API_KEY in the server environment before generating questions.",
        )
    if len(set(payload.question_types)) != len(payload.question_types):
        raise HTTPException(status_code=422, detail="Question types must be unique.")
    return _owned_source(source_id, user["user_id"])


def _store_quiz(
    quiz_id: str,
    user_id: int,
    source_id: str,
    payload: QuizRequest,
    questions: list[dict],
) -> None:
    now = timestamp()
    with connect() as connection:
        connection.execute(
            """
            INSERT INTO quizzes(id, user_id, source_id, mode, questions_json, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                quiz_id,
                user_id,
                source_id,
                payload.mode,
                json.dumps(questions, ensure_ascii=False),
                now,
            ),
        )
        connection.execute(
            """
            INSERT INTO quiz_attempts(
                quiz_id, user_id, source_id, mode, difficulty, question_types_json,
                total_questions, status, started_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'in_progress', ?)
            """,
            (
                quiz_id,
                user_id,
                source_id,
                payload.mode,
                payload.difficulty,
                json.dumps(payload.question_types),
                len(questions),
                now,
            ),
        )


def _set_job_progress(job_id: str, progress: int, message: str) -> None:
    with connect() as connection:
        connection.execute(
            """
            UPDATE generation_jobs SET status = 'running', progress = MAX(progress, ?), message = ?,
                updated_at = ? WHERE id = ?
            """,
            (min(max(progress, 0), 99), message[:200], timestamp(), job_id),
        )


def _run_generation_job(
    job_id: str,
    user_id: int,
    username: str,
    source_id: str,
    source_content: str,
    request_json: str,
) -> None:
    try:
        validate_json = getattr(QuizRequest, "model_validate_json", None)
        payload = (
            validate_json(request_json)
            if validate_json
            else QuizRequest.parse_raw(request_json)
        )
        _set_job_progress(job_id, 10, "Preparing your selected material")

        def update_progress(completed: int, total: int) -> None:
            percentage = 20 + round(70 * completed / max(total, 1))
            _set_job_progress(
                job_id,
                percentage,
                f"Generated and checked source section {completed} of {total}",
            )

        def update_tokens(
            context_index: int,
            total_contexts: int,
            generated_characters: int,
            estimated_characters: int,
        ) -> None:
            within_section = min(generated_characters / max(estimated_characters, 1), 0.99)
            fraction = (context_index - 1 + within_section) / max(total_contexts, 1)
            _set_job_progress(
                job_id,
                15 + round(70 * fraction),
                f"Generating questions from section {context_index} of {total_contexts}",
            )

        questions = generate_questions(
            source_content,
            payload.count,
            payload.sample_questions,
            question_types=payload.question_types,
            difficulty=payload.difficulty,
            progress_callback=update_progress,
            token_progress_callback=update_tokens,
        )
        _set_job_progress(job_id, 95, "Saving your quiz and attempt record")
        quiz_id = str(uuid.uuid4())
        _store_quiz(quiz_id, user_id, source_id, payload, questions)
        with connect() as connection:
            connection.execute(
                """
                UPDATE generation_jobs
                SET status = 'completed', progress = 100, message = ?,
                    quiz_id = ?, error = NULL, updated_at = ?
                WHERE id = ? AND user_id = ?
                """,
                ("Question generation complete", quiz_id, timestamp(), job_id, user_id),
            )
        _write_log(
            action="quiz.generation",
            status="success",
            user_id=user_id,
            username=username,
            details=f"job_id={job_id} quiz_id={quiz_id} count={len(questions)}",
        )
    except Exception as error:
        log.error("Quiz generation job failed: job_id=%s exception=%s", job_id, type(error).__name__)
        with connect() as connection:
            connection.execute(
                """
                UPDATE generation_jobs SET status = 'failed', message = ?,
                    error = ?, updated_at = ? WHERE id = ? AND user_id = ?
                """,
                (
                    "Question generation failed",
                    "Generation failed. Check the server logs and model configuration.",
                    timestamp(),
                    job_id,
                    user_id,
                ),
            )
        failure_detail = (
            error.diagnostic
            if isinstance(error, QuestionGenerationError) and error.diagnostic
            else f"exception={type(error).__name__}"
        )
        _write_log(
            action="quiz.generation",
            status="failed",
            user_id=user_id,
            username=username,
            details=f"job_id={job_id} {failure_detail}",
        )


def _login_response(user_id: int, username: str) -> JSONResponse:
    token, csrf_token = create_session(user_id)
    response = JSONResponse(
        {
            "username": username,
            "csrf_token": csrf_token,
            "is_admin": _is_admin_username(username),
        }
    )
    response.set_cookie(
        SESSION_COOKIE,
        token,
        max_age=14 * 24 * 60 * 60,
        httponly=True,
        secure=os.getenv("PORTAL_SECURE_COOKIES", "false").lower() in {"1", "true", "yes"},
        samesite="strict",
        path="/",
    )
    return response


def _clear_session_cookie(response: JSONResponse) -> None:
    response.delete_cookie(
        SESSION_COOKIE,
        httponly=True,
        secure=os.getenv("PORTAL_SECURE_COOKIES", "false").lower() in {"1", "true", "yes"},
        samesite="strict",
        path="/",
    )


def _event_count(kind: str, key_hash: str, window: timedelta) -> int:
    cutoff = timestamp(utc_now() - window)
    with connect() as connection:
        row = connection.execute(
            "SELECT COUNT(*) AS count FROM auth_events WHERE kind = ? AND key_hash = ? "
            "AND created_at > ?",
            (kind, key_hash, cutoff),
        ).fetchone()
    return int(row["count"])


def _record_event(kind: str, key_hash: str) -> None:
    with connect() as connection:
        connection.execute(
            "INSERT INTO auth_events(kind, key_hash, created_at) VALUES (?, ?, ?)",
            (kind, key_hash, timestamp()),
        )


def _clear_events(kind: str, key_hash: str) -> None:
    with connect() as connection:
        connection.execute(
            "DELETE FROM auth_events WHERE kind = ? AND key_hash = ?",
            (kind, key_hash),
        )


def _rate_limit(kind: str, key_hash: str, *, limit: int, window: timedelta) -> None:
    if _event_count(kind, key_hash, window) >= limit:
        raise HTTPException(
            status_code=429,
            detail="Too many requests. Please wait and try again later.",
        )
    _record_event(kind, key_hash)


def _owned_source(source_id: str, user_id: int):
    with connect() as connection:
        source = connection.execute(
            "SELECT * FROM sources WHERE id = ? AND user_id = ?",
            (source_id, user_id),
        ).fetchone()
    if source is None:
        raise HTTPException(status_code=404, detail="Source not found.")
    return source


def _owned_quiz(quiz_id: str, user_id: int):
    with connect() as connection:
        quiz = connection.execute(
            "SELECT * FROM quizzes WHERE id = ? AND user_id = ?",
            (quiz_id, user_id),
        ).fetchone()
    if quiz is None:
        raise HTTPException(status_code=404, detail="Quiz not found.")
    return quiz


def _attempt_for_quiz(quiz_id: str):
    with connect() as connection:
        attempt = connection.execute(
            "SELECT * FROM quiz_attempts WHERE quiz_id = ?", (quiz_id,)
        ).fetchone()
    if attempt is None:
        raise HTTPException(status_code=404, detail="Quiz attempt not found.")
    return attempt


def _quiz_view(
    quiz_id: str,
    mode: str,
    questions: list[dict],
    current_index: int,
    completed: bool,
    score_percent: int | None,
    difficulty: str = "medium",
    question_types: list[str] | None = None,
) -> dict:
    result = {
        "id": quiz_id,
        "mode": mode,
        "total": len(questions),
        "current_index": current_index,
        "completed": completed,
        "difficulty": difficulty,
        "question_types": question_types or ["knowledge"],
    }
    if completed:
        result["score_percent"] = score_percent
    elif mode == "learning":
        result["question"] = public_questions([questions[current_index]])[0]
    else:
        result["questions"] = public_questions(questions)
    return result
