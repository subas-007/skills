"""SQLite persistence for portal accounts, source material, and quiz attempts."""

from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


def data_directory() -> Path:
    return Path(os.getenv("PORTAL_DATA_DIR", "./portal-data")).expanduser().resolve()


def database_path() -> Path:
    return data_directory() / "portal.sqlite3"


@contextmanager
def connect() -> Iterator[sqlite3.Connection]:
    path = database_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path, timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 30000")
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def initialize_database() -> None:
    with connect() as connection:
        connection.execute("PRAGMA journal_mode = WAL")
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT NOT NULL COLLATE NOCASE UNIQUE,
                password_hash TEXT NOT NULL,
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token_hash TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                csrf_token TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions(user_id);
            CREATE TABLE IF NOT EXISTS auth_events (
                id INTEGER PRIMARY KEY,
                kind TEXT NOT NULL,
                key_hash TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS auth_events_lookup_idx
                ON auth_events(kind, key_hash, created_at);
            CREATE TABLE IF NOT EXISTS sources (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                title TEXT NOT NULL,
                source_type TEXT NOT NULL,
                content TEXT NOT NULL,
                file_name TEXT,
                file_data BLOB,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS sources_user_idx ON sources(user_id, created_at);
            CREATE TABLE IF NOT EXISTS quizzes (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                source_id TEXT NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
                mode TEXT NOT NULL CHECK(mode IN ('learning', 'exam')),
                questions_json TEXT NOT NULL,
                answers_json TEXT NOT NULL DEFAULT '[]',
                current_index INTEGER NOT NULL DEFAULT 0,
                completed INTEGER NOT NULL DEFAULT 0,
                score_percent INTEGER,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS quizzes_user_idx ON quizzes(user_id, created_at);
            CREATE TABLE IF NOT EXISTS quiz_attempts (
                quiz_id TEXT PRIMARY KEY REFERENCES quizzes(id) ON DELETE CASCADE,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                source_id TEXT NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
                mode TEXT NOT NULL,
                difficulty TEXT NOT NULL,
                question_types_json TEXT NOT NULL,
                total_questions INTEGER NOT NULL,
                status TEXT NOT NULL CHECK(status IN ('in_progress', 'completed', 'failed')),
                score_percent INTEGER,
                started_at TEXT NOT NULL,
                completed_at TEXT
            );
            CREATE INDEX IF NOT EXISTS quiz_attempts_user_idx
                ON quiz_attempts(user_id, started_at);
            CREATE TABLE IF NOT EXISTS generation_jobs (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                source_id TEXT NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
                status TEXT NOT NULL CHECK(status IN ('queued', 'running', 'completed', 'failed')),
                progress INTEGER NOT NULL DEFAULT 0,
                message TEXT NOT NULL,
                request_json TEXT NOT NULL,
                quiz_id TEXT REFERENCES quizzes(id) ON DELETE SET NULL,
                error TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS generation_jobs_user_idx
                ON generation_jobs(user_id, created_at);
            CREATE TABLE IF NOT EXISTS portal_logs (
                id INTEGER PRIMARY KEY,
                user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
                username TEXT,
                action TEXT NOT NULL,
                status TEXT NOT NULL,
                details TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS portal_logs_created_idx ON portal_logs(created_at);
            CREATE TABLE IF NOT EXISTS qna_conversations (
                id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                source_id TEXT NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
                title TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS qna_conversations_user_idx
                ON qna_conversations(user_id, updated_at);
            CREATE TABLE IF NOT EXISTS qna_messages (
                id INTEGER PRIMARY KEY,
                conversation_id TEXT NOT NULL REFERENCES qna_conversations(id) ON DELETE CASCADE,
                role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS qna_messages_conversation_idx
                ON qna_messages(conversation_id, id);
            """
        )
        user_columns = {
            row["name"] for row in connection.execute("PRAGMA table_info(users)").fetchall()
        }
        if "is_active" not in user_columns:
            connection.execute(
                "ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1"
            )
        source_columns = {
            row["name"] for row in connection.execute("PRAGMA table_info(sources)").fetchall()
        }
        if "file_name" not in source_columns:
            connection.execute("ALTER TABLE sources ADD COLUMN file_name TEXT")
        if "file_data" not in source_columns:
            connection.execute("ALTER TABLE sources ADD COLUMN file_data BLOB")
        connection.execute(
            """
            INSERT OR IGNORE INTO quiz_attempts(
                quiz_id, user_id, source_id, mode, difficulty, question_types_json,
                total_questions, status, score_percent, started_at, completed_at
            )
            SELECT id, user_id, source_id, mode, 'medium', '["knowledge"]',
                   json_array_length(questions_json),
                   CASE WHEN completed = 1 THEN 'completed' ELSE 'in_progress' END,
                   score_percent, created_at,
                   CASE WHEN completed = 1 THEN created_at ELSE NULL END
            FROM quizzes
            """
        )
