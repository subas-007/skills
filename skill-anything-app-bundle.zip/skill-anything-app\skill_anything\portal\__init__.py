"""Browser-based multi-user learning portal."""
