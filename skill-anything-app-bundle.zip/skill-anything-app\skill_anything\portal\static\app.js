"use strict";

const authView = document.getElementById("auth-view");
const portalView = document.getElementById("portal-view");
const authForm = document.getElementById("auth-form");
const authError = document.getElementById("auth-error");
const portalError = document.getElementById("portal-error");
const quizPanel = document.getElementById("quiz-panel");
let csrfToken = "";
let authMode = "login";
let selectedSourceId = "";
let availableSources = [];
let currentQuiz = null;
let currentQnaConversationId = "";

async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  const method = (options.method || "GET").toUpperCase();
  if (csrfToken && !["GET", "HEAD", "OPTIONS"].includes(method)) {
    headers.set("X-CSRF-Token", csrfToken);
  }
  if (options.body && !(options.body instanceof FormData)) {
    headers.set("Content-Type", "application/json");
  }
  const response = await fetch(path, {
    ...options,
    headers,
    credentials: "same-origin",
  });
  let payload;
  try {
    payload = await response.json();
  } catch {
    throw new Error("The server returned an invalid response.");
  }
  if (!response.ok) {
    const error = new Error(payload.detail || `Request failed (${response.status}).`);
    error.status = response.status;
    throw error;
  }
  return payload;
}

function showError(element, message) {
  element.textContent = message;
  element.hidden = false;
}

function hideError(element) {
  element.textContent = "";
  element.hidden = true;
}

function setAuthenticated(user) {
  csrfToken = user.csrf_token;
  document.getElementById("username-label").textContent = user.username;
  document.getElementById("account-bar").hidden = false;
  authView.hidden = true;
  portalView.hidden = false;
  document.querySelectorAll('[data-role="learner"]').forEach((element) => {
    element.hidden = user.is_admin;
  });
  document.querySelector(".hero").hidden = user.is_admin;
  document.getElementById("model-status").hidden = user.is_admin;
  document.getElementById("admin-tab").hidden = !user.is_admin;
  activatePanel(user.is_admin ? "admin-view" : "resources-view");
  hideError(portalError);
  if (user.is_admin) {
    refreshAdmin();
  } else {
    refreshSources();
    refreshConfig();
    refreshHistory();
    refreshQnaConversations();
  }
}

function setAuthMode(mode) {
  authMode = mode;
  document.getElementById("login-tab").classList.toggle("active", mode === "login");
  document.getElementById("register-tab").classList.toggle("active", mode === "register");
  document.getElementById("auth-submit").textContent =
    mode === "login" ? "Sign in" : "Create account";
  document.getElementById("password").autocomplete =
    mode === "login" ? "current-password" : "new-password";
  document.getElementById("password-help").hidden = mode === "login";
  hideError(authError);
}

function addText(parent, tag, text, className = "") {
  const element = document.createElement(tag);
  element.textContent = text;
  if (className) element.className = className;
  parent.append(element);
  return element;
}

async function refreshConfig() {
  try {
    const config = await api("/api/config");
    const status = document.getElementById("model-status");
    status.classList.toggle("warning", !config.model_configured);
    status.textContent = config.model_configured
      ? `AI questions use the server-configured model (${config.model}).`
      : "Question generation is not configured yet. Ask the administrator to set the API key on the server.";
  } catch (error) {
    showError(portalError, error.message);
  }
}

async function refreshSources() {
  const container = document.getElementById("saved-sources");
  container.replaceChildren();
  try {
    const sources = await api("/api/sources");
    availableSources = sources;
    for (const source of sources) {
      const entry = document.createElement("div");
      entry.className = "source-entry";
      const button = document.createElement("button");
      button.type = "button";
      button.className = "source-item";
      button.classList.toggle("selected", source.id === selectedSourceId);
      addText(button, "span", source.title);
      addText(button, "small", `${source.source_type} · ${source.created_at}`);
      button.addEventListener("click", () => {
        selectedSourceId = source.id;
        document.getElementById("quiz-source").value = source.id;
        document.getElementById("qna-source").value = source.id;
        refreshQnaPreview();
        document.querySelectorAll(".source-item").forEach((item) => {
          item.classList.toggle("selected", item === button);
        });
      });
      const remove = addText(entry, "button", "Delete", "delete-source");
      remove.type = "button";
      remove.setAttribute("aria-label", `Delete ${source.title}`);
      remove.addEventListener("click", async () => {
        try {
          await api(`/api/sources/${source.id}`, { method: "DELETE" });
          if (selectedSourceId === source.id) selectedSourceId = "";
          await refreshSources();
        } catch (error) {
          showError(portalError, error.message);
        }
      });
      entry.prepend(button);
      container.append(entry);
    }
    const qnaSource = document.getElementById("qna-source");
    selectedSourceId = sources.some((source) => source.id === selectedSourceId)
      ? selectedSourceId
      : sources[0]?.id || "";
    for (const select of [qnaSource, document.getElementById("quiz-source")]) {
      select.replaceChildren();
      sources.forEach((source) => {
        const option = document.createElement("option");
        option.value = source.id;
        option.textContent = source.title;
        select.append(option);
      });
      select.value = selectedSourceId;
      select.disabled = !sources.length;
    }
    refreshQnaPreview();
    document.getElementById("generate-button").disabled = !sources.length;
    document.querySelector('#qna-form button[type="submit"]').disabled = !sources.length;
  } catch (error) {
    showError(portalError, error.message);
  }
}

function refreshQnaPreview() {
  const source = availableSources.find(
    (item) => item.id === document.getElementById("qna-source").value,
  );
  const frame = document.getElementById("qna-preview-frame");
  const message = document.getElementById("qna-preview-message");
  if (!source) {
    frame.removeAttribute("src");
    frame.hidden = true;
    message.textContent = "Upload a PDF or Word document to preview it here.";
    return;
  }
  if (!source.preview_available) {
    frame.removeAttribute("src");
    frame.hidden = true;
    message.textContent = "A preview is available for uploaded PDF and Word documents.";
    return;
  }
  message.textContent = `Previewing ${source.title}`;
  frame.src = `/api/sources/${encodeURIComponent(source.id)}/preview`;
  frame.hidden = false;
}

authForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  hideError(authError);
  const form = new FormData(authForm);
  try {
    const user = await api(`/api/auth/${authMode}`, {
      method: "POST",
      body: JSON.stringify({
        username: form.get("username"),
        password: form.get("password"),
      }),
    });
    authForm.reset();
    setAuthenticated(user);
  } catch (error) {
    showError(authError, error.message);
  }
});

document.getElementById("login-tab").addEventListener("click", () => setAuthMode("login"));
document.getElementById("register-tab").addEventListener("click", () => setAuthMode("register"));

document.getElementById("logout-button").addEventListener("click", async () => {
  try {
    await api("/api/auth/logout", { method: "POST", body: "{}" });
    csrfToken = "";
    selectedSourceId = "";
    availableSources = [];
    currentQuiz = null;
    currentQnaConversationId = "";
    portalView.hidden = true;
    authView.hidden = false;
    document.getElementById("account-bar").hidden = true;
    quizPanel.hidden = true;
    document.getElementById("admin-tab").hidden = true;
    document.querySelectorAll('[data-role="learner"]').forEach((element) => {
      element.hidden = false;
    });
    document.querySelector(".hero").hidden = false;
    document.getElementById("model-status").hidden = false;
    activatePanel("resources-view");
    document.getElementById("qna-messages").replaceChildren();
  } catch (error) {
    showError(portalError, error.message);
  }
});

async function saveSource(form, endpoint, body) {
  hideError(portalError);
  const button = form.querySelector("button[type=submit]");
  button.disabled = true;
  const originalText = button.textContent;
  button.textContent = "Saving resource...";
  try {
    const source = await api(endpoint, { method: "POST", body });
    selectedSourceId = source.id;
    const result = document.getElementById("source-result");
    result.textContent = `Added "${source.title}" (${source.characters.toLocaleString()} characters).`;
    result.hidden = false;
    form.reset();
    await refreshSources();
  } catch (error) {
    showError(portalError, error.message);
  } finally {
    button.disabled = false;
    button.textContent = originalText;
  }
}

document.getElementById("upload-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const body = new FormData();
  body.append("file", document.getElementById("source-file").files[0]);
  void saveSource(event.currentTarget, "/api/sources/upload", body);
});

document.getElementById("url-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const body = new FormData();
  body.append("url", document.getElementById("source-url").value.trim());
  void saveSource(event.currentTarget, "/api/sources/from-url", body);
});

document.getElementById("quiz-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  hideError(portalError);
  selectedSourceId = document.getElementById("quiz-source").value;
  if (!selectedSourceId) {
    showError(portalError, "Add or select study material first.");
    return;
  }
  const button = document.getElementById("generate-button");
  button.disabled = true;
  const originalText = button.textContent;
  button.textContent = "Generating questions...";
  const progressContainer = document.getElementById("generation-progress");
  const progressBar = document.getElementById("generation-progress-bar");
  const progressText = document.getElementById("generation-progress-text");
  progressContainer.hidden = false;
  progressBar.value = 0;
  progressText.textContent = "Preparing generation...";
  const mode = document.querySelector('input[name="mode"]:checked').value;
  try {
    const selectedTypes = [...document.querySelectorAll('input[name="question-type"]:checked')]
      .map((input) => input.value);
    if (!selectedTypes.length) {
      throw new Error("Select at least one question type.");
    }
    const job = await api(`/api/sources/${selectedSourceId}/quiz-jobs`, {
      method: "POST",
      body: JSON.stringify({
        mode,
        count: Number(document.getElementById("question-count").value),
        sample_questions: document.getElementById("sample-questions").value,
        question_types: selectedTypes,
        difficulty: document.getElementById("difficulty").value,
        confirm_external_processing: document.getElementById("processing-consent").checked,
      }),
    });
    let status;
    do {
      await new Promise((resolve) => setTimeout(resolve, 750));
      status = await api(`/api/quiz-jobs/${job.job_id}`);
      progressBar.value = status.progress;
      progressText.textContent = `${status.progress}% · ${status.message}`;
      if (status.status === "failed") throw new Error(status.error);
    } while (status.status !== "completed");
    currentQuiz = status.quiz;
    quizPanel.hidden = false;
    document.getElementById("quiz-title").textContent =
      mode === "learning" ? "Learning mode" : "Exam mode";
    if (mode === "learning") {
      renderLearningQuestion(currentQuiz);
    } else {
      renderExam(currentQuiz);
    }
    quizPanel.scrollIntoView({ behavior: "smooth", block: "start" });
    await refreshHistory();
  } catch (error) {
    showError(portalError, error.message);
  } finally {
    button.disabled = false;
    button.textContent = originalText;
    if (progressBar.value === 100) {
      progressText.textContent = "100% · Question generation complete";
    } else if (portalError.hidden) {
      progressContainer.hidden = true;
    }
  }
});

function renderLearningQuestion(quiz) {
  const content = document.getElementById("quiz-content");
  content.replaceChildren();
  if (quiz.completed) {
    renderScore(content, quiz.score_percent);
    return;
  }
  document.getElementById("quiz-progress").textContent =
    `Question ${quiz.current_index + 1} of ${quiz.total}`;
  const questionCard = document.createElement("div");
  questionCard.className = "question-card";
  addText(questionCard, "h3", quiz.question.question);
  addText(questionCard, "span", quiz.question.question_type, "question-type");
  const options = document.createElement("div");
  quiz.question.options.forEach((option, index) => {
    const label = document.createElement("label");
    label.className = "answer-option";
    const radio = document.createElement("input");
    radio.type = "radio";
    radio.name = "learning-answer";
    radio.value = String(index);
    label.append(radio);
    addText(label, "span", option);
    options.append(label);
  });
  questionCard.append(options);
  content.append(questionCard);
  const submit = addText(content, "button", "Check answer", "button button-primary");
  submit.type = "button";
  submit.addEventListener("click", async () => {
    const selected = content.querySelector('input[name="learning-answer"]:checked');
    if (!selected) {
      showError(portalError, "Choose an answer first.");
      return;
    }
    submit.disabled = true;
    try {
      const result = await api(`/api/quizzes/${quiz.id}/answer`, {
        method: "POST",
        body: JSON.stringify({
          question_index: quiz.current_index,
          option_index: Number(selected.value),
        }),
      });
      renderFeedback(content, result.feedback, Number(selected.value));
      const next = addText(
        content,
        "button",
        result.completed ? "See result" : "Next question",
        "button button-primary",
      );
      next.type = "button";
      next.addEventListener("click", async () => {
        if (result.completed) {
          renderScore(content, result.score_percent);
          void refreshHistory();
          return;
        }
        try {
          const nextQuiz = await api(`/api/quizzes/${quiz.id}`);
          renderLearningQuestion(nextQuiz);
        } catch (error) {
          showError(portalError, error.message);
        }
      });
    } catch (error) {
      submit.disabled = false;
      showError(portalError, error.message);
    }
  });
}

function renderFeedback(parent, feedback, selectedIndex) {
  const panel = document.createElement("section");
  panel.className = `feedback ${feedback.correct ? "correct" : "incorrect"}`;
  addText(
    panel,
    "h3",
    feedback.correct ? "Correct" : "Not quite. Review each option:",
  );
  addText(panel, "p", feedback.explanation);
  const rationales = document.createElement("ol");
  rationales.className = "rationale-list";
  feedback.option_explanations.forEach((reason, index) => {
    const prefix = index === feedback.correct_index ? "Correct answer: " : "Incorrect: ";
    const chosen = index === selectedIndex ? " (your answer)" : "";
    addText(rationales, "li", `${prefix}${reason}${chosen}`);
  });
  panel.append(rationales);
  addText(panel, "p", `Source: “${feedback.evidence}”`, "hint");
  parent.append(panel);
}

function renderExam(quiz) {
  const content = document.getElementById("quiz-content");
  content.replaceChildren();
  document.getElementById("quiz-progress").textContent =
    `${quiz.total} questions · answers are hidden until you submit`;
  quiz.questions.forEach((question, questionIndex) => {
    const card = document.createElement("div");
    card.className = "question-card";
    addText(card, "h3", `${questionIndex + 1}. ${question.question}`);
    addText(card, "span", question.question_type, "question-type");
    question.options.forEach((option, optionIndex) => {
      const label = document.createElement("label");
      label.className = "answer-option";
      const radio = document.createElement("input");
      radio.type = "radio";
      radio.name = `exam-${questionIndex}`;
      radio.value = String(optionIndex);
      label.append(radio);
      addText(label, "span", option);
      card.append(label);
    });
    content.append(card);
  });
  const submit = addText(content, "button", "Submit exam", "button button-primary");
  submit.type = "button";
  submit.addEventListener("click", async () => {
    const answers = quiz.questions.map((_, index) => {
      const selected = content.querySelector(`input[name="exam-${index}"]:checked`);
      return selected ? Number(selected.value) : null;
    });
    if (answers.some((answer) => answer === null)) {
      showError(portalError, "Answer every question before submitting.");
      return;
    }
    submit.disabled = true;
    try {
      const result = await api(`/api/quizzes/${quiz.id}/submit`, {
        method: "POST",
        body: JSON.stringify({ answers }),
      });
      renderScore(content, result.score_percent);
      void refreshHistory();
    } catch (error) {
      submit.disabled = false;
      showError(portalError, error.message);
    }
  });
}

function renderScore(parent, score) {
  parent.replaceChildren();
  document.getElementById("quiz-progress").textContent = "Quiz complete";
  const result = document.createElement("div");
  result.className = "feedback";
  addText(result, "h3", "Your result");
  addText(result, "p", `${score}%`, "score");
  addText(result, "p", "Start another quiz when you are ready.");
  parent.append(result);
}

function renderTable(container, headings, rows) {
  container.replaceChildren();
  if (!rows.length) {
    addText(container, "p", "No records yet.", "muted");
    return;
  }
  const table = document.createElement("table");
  const head = document.createElement("thead");
  const headerRow = document.createElement("tr");
  headings.forEach((heading) => addText(headerRow, "th", heading));
  head.append(headerRow);
  table.append(head);
  const body = document.createElement("tbody");
  rows.forEach((cells) => {
    const row = document.createElement("tr");
    cells.forEach((cell) => {
      const td = document.createElement("td");
      if (cell instanceof Node) td.append(cell);
      else td.textContent = cell === null || cell === undefined ? "—" : String(cell);
      row.append(td);
    });
    body.append(row);
  });
  table.append(body);
  container.append(table);
}

async function refreshHistory() {
  const container = document.getElementById("attempt-history");
  if (!container) return;
  try {
    const attempts = await api("/api/history");
    renderTable(
      container,
      ["Material", "Mode", "Difficulty", "Question types", "Questions", "Result", "Started"],
      attempts.map((attempt) => [
        attempt.source_title,
        attempt.mode,
        attempt.difficulty,
        attempt.question_types.join(", "),
        attempt.total_questions,
        attempt.status === "completed" ? `${attempt.score_percent}%` : attempt.status,
        new Date(attempt.started_at).toLocaleString(),
      ]),
    );
  } catch (error) {
    showError(portalError, error.message);
  }
}

function renderQnaMessages(messages) {
  const container = document.getElementById("qna-messages");
  container.replaceChildren();
  messages.forEach((message) => {
    const bubble = document.createElement("article");
    bubble.className = `qna-message ${message.role}`;
    addText(bubble, "strong", message.role === "user" ? "You" : "Answer");
    addText(bubble, "p", message.content);
    container.append(bubble);
  });
  container.scrollTop = container.scrollHeight;
}

async function refreshQnaConversations() {
  const container = document.getElementById("qna-conversations");
  if (!container) return;
  try {
    const conversations = await api("/api/qna");
    container.replaceChildren();
    conversations.forEach((conversation) => {
      const button = addText(
        container,
        "button",
        `${conversation.title} · ${conversation.source_title}`,
        "source-item",
      );
      button.type = "button";
      button.addEventListener("click", async () => {
        try {
          const result = await api(`/api/qna/${conversation.id}`);
          currentQnaConversationId = conversation.id;
          document.getElementById("qna-source").value = conversation.source_id;
          refreshQnaPreview();
          renderQnaMessages(result.messages);
        } catch (error) {
          showError(portalError, error.message);
        }
      });
    });
    if (!conversations.length) addText(container, "p", "No conversations yet.", "muted");
  } catch (error) {
    showError(portalError, error.message);
  }
}

document.getElementById("qna-source").addEventListener("change", () => {
  currentQnaConversationId = "";
  document.getElementById("qna-messages").replaceChildren();
  refreshQnaPreview();
});

document.getElementById("quiz-source").addEventListener("change", (event) => {
  selectedSourceId = event.currentTarget.value;
});

document.getElementById("qna-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  hideError(portalError);
  const sourceId = document.getElementById("qna-source").value;
  const questionText = document.getElementById("qna-question").value.trim();
  if (!sourceId || !questionText) {
    showError(portalError, "Choose study material and enter a question.");
    return;
  }
  const button = event.currentTarget.querySelector("button[type=submit]");
  button.disabled = true;
  const messages = [...document.querySelectorAll(".qna-message")].map((element) => ({
    role: element.classList.contains("user") ? "user" : "assistant",
    content: element.querySelector("p").textContent,
  }));
  messages.push({ role: "user", content: questionText });
  renderQnaMessages(messages);
  try {
    const result = await api("/api/qna", {
      method: "POST",
      body: JSON.stringify({
        source_id: sourceId,
        question: questionText,
        conversation_id: currentQnaConversationId || null,
      }),
    });
    currentQnaConversationId = result.conversation_id;
    messages.push({ role: "assistant", content: result.answer });
    renderQnaMessages(messages);
    event.currentTarget.reset();
    await refreshQnaConversations();
  } catch (error) {
    showError(portalError, error.message);
  } finally {
    button.disabled = false;
  }
});

async function refreshAdmin() {
  try {
    const [summary, users, sources, logs] = await Promise.all([
      api("/api/admin/summary"),
      api("/api/admin/users"),
      api("/api/admin/sources"),
      api("/api/admin/logs?limit=200"),
    ]);
    const summaryContainer = document.getElementById("admin-summary");
    summaryContainer.replaceChildren();
    [
      ["Users", summary.users],
      ["Resources", summary.sources],
      ["Quiz attempts", summary.attempts],
      ["Completed", summary.completed_attempts],
      ["Average score", summary.average_score === null ? "—" : `${summary.average_score}%`],
    ].forEach(([label, value]) => {
      const card = document.createElement("div");
      card.className = "summary-item";
      addText(card, "strong", value);
      addText(card, "span", label);
      summaryContainer.append(card);
    });
    renderTable(
      document.getElementById("admin-users"),
      ["Username", "Role", "Status", "Resources", "Attempts", "Average", "Manage"],
      users.map((user) => {
        const toggle = addText(
          document.createElement("button"),
          "button",
          user.is_active ? "Disable" : "Enable",
          "button button-secondary",
        );
        toggle.type = "button";
        toggle.addEventListener("click", async () => {
          try {
            await api(`/api/admin/users/${user.id}`, {
              method: "PATCH",
              body: JSON.stringify({ is_active: !user.is_active }),
            });
            await refreshAdmin();
          } catch (error) {
            showError(portalError, error.message);
          }
        });
        const report = addText(
          document.createElement("button"),
          "button",
          "Attempts",
          "button button-secondary",
        );
        report.type = "button";
        report.addEventListener("click", async () => {
          try {
            const attempts = await api(`/api/admin/users/${user.id}/attempts`);
            renderTable(
              document.getElementById("admin-user-report"),
              ["User", "Material", "Mode", "Difficulty", "Questions", "Result", "Started"],
              attempts.map((attempt) => [
                user.username,
                attempt.source_title,
                attempt.mode,
                attempt.difficulty,
                attempt.total_questions,
                attempt.status === "completed" ? `${attempt.score_percent}%` : attempt.status,
                new Date(attempt.started_at).toLocaleString(),
              ]),
            );
          } catch (error) {
            showError(portalError, error.message);
          }
        });
        const actions = document.createElement("div");
        actions.className = "admin-actions";
        actions.append(report, toggle);
        return [
          user.username,
          user.role,
          user.is_active ? "Active" : "Disabled",
          user.source_count,
          user.attempt_count,
          user.average_score === null ? "—" : `${user.average_score}%`,
          actions,
        ];
      }),
    );
    renderTable(
      document.getElementById("admin-sources"),
      ["Resource", "Owner", "Type", "Characters", "Added", "Manage"],
      sources.map((source) => {
        const remove = addText(
          document.createElement("button"),
          "button",
          "Delete",
          "delete-source",
        );
        remove.type = "button";
        remove.addEventListener("click", async () => {
          if (!window.confirm(`Delete "${source.title}" and its associated records?`)) return;
          try {
            await api(`/api/admin/sources/${source.id}`, { method: "DELETE" });
            await refreshAdmin();
          } catch (error) {
            showError(portalError, error.message);
          }
        });
        return [
          source.title,
          source.username,
          source.source_type,
          source.characters,
          new Date(source.created_at).toLocaleString(),
          remove,
        ];
      }),
    );
    renderTable(
      document.getElementById("admin-logs"),
      ["Time", "User", "Action", "Status", "Details"],
      logs.map((entry) => [
        new Date(entry.created_at).toLocaleString(),
        entry.username,
        entry.action,
        entry.status,
        entry.details,
      ]),
    );
  } catch (error) {
    showError(portalError, error.message);
  }
}

function activatePanel(panelId) {
  document.querySelectorAll(".portal-tabs [data-panel]").forEach((tab) => {
    const active = tab.dataset.panel === panelId;
    tab.classList.toggle("active", active);
    document.getElementById(tab.dataset.panel).hidden = !active;
  });
}

document.querySelectorAll(".portal-tabs [data-panel]").forEach((tab) => {
  tab.addEventListener("click", () => {
    activatePanel(tab.dataset.panel);
    if (tab.dataset.panel === "history-view") void refreshHistory();
    if (tab.dataset.panel === "admin-view") void refreshAdmin();
  });
});

async function start() {
  try {
    const user = await api("/api/me");
    if (user.authenticated) {
      setAuthenticated(user);
    } else {
      authView.hidden = false;
      portalView.hidden = true;
    }
  } catch (error) {
    showError(authError, error.message);
  }
}

start();
