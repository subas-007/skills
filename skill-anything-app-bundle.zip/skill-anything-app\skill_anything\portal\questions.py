"""MCQ generation and validation for learning and exam modes."""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Callable, Iterable

from skill_anything.llm import chat

MAX_CONTEXTS = 8
CONTEXT_CHARS = 7_000
log = logging.getLogger(__name__)


class QuestionGenerationError(RuntimeError):
    """The configured model failed to return a usable MCQ set."""

    def __init__(self, message: str, *, diagnostic: str = "") -> None:
        super().__init__(message)
        self.diagnostic = diagnostic


def _windows(content: str) -> list[str]:
    paragraphs = [part.strip() for part in content.split("\n") if part.strip()]
    result: list[str] = []
    current: list[str] = []
    current_length = 0
    for paragraph in paragraphs:
        while len(paragraph) > CONTEXT_CHARS:
            if current:
                result.append("\n".join(current))
                current, current_length = [], 0
            result.append(paragraph[:CONTEXT_CHARS])
            paragraph = paragraph[CONTEXT_CHARS:]
        if current and current_length + len(paragraph) + 1 > CONTEXT_CHARS:
            result.append("\n".join(current))
            current, current_length = [], 0
        current.append(paragraph)
        current_length += len(paragraph) + 1
    if current:
        result.append("\n".join(current))
    return result or [content[:CONTEXT_CHARS]]


def _select_contexts(windows: list[str], count: int) -> list[str]:
    limit = min(len(windows), count, MAX_CONTEXTS)
    if limit == len(windows):
        return windows
    if limit == 1:
        return [windows[len(windows) // 2]]
    indexes = {
        round(index * (len(windows) - 1) / (limit - 1))
        for index in range(limit)
    }
    return [windows[index] for index in sorted(indexes)]


def _distribute(total: int, slots: int) -> list[int]:
    quotient, remainder = divmod(total, slots)
    return [quotient + (index < remainder) for index in range(slots)]


def _parse_array(raw: str) -> list[dict]:
    text = raw.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.IGNORECASE)
    start, end = text.find("["), text.rfind("]")
    if start < 0 or end < start:
        raise QuestionGenerationError("The model response was not a JSON question list.")
    try:
        result = json.loads(text[start : end + 1])
    except json.JSONDecodeError as error:
        raise QuestionGenerationError("The model returned invalid question JSON.") from error
    if not isinstance(result, list) or not all(isinstance(item, dict) for item in result):
        raise QuestionGenerationError("The model response did not contain valid questions.")
    return result


def _validated_question(
    item: dict, source_window: str, default_type: str = "knowledge"
) -> dict:
    question = item.get("question")
    options = item.get("options")
    correct_index = item.get("correct_index", item.get("answer_index"))
    explanation = item.get("explanation")
    rationales = item.get("option_explanations")
    evidence = item.get("evidence")
    question_type = item.get("question_type", default_type)

    if (
        not isinstance(question, str)
        or not question.strip()
        or not isinstance(options, list)
        or len(options) != 4
        or not all(isinstance(option, str) and option.strip() for option in options)
        or len({option.strip().casefold() for option in options}) != 4
        or isinstance(correct_index, bool)
        or not isinstance(correct_index, int)
        or correct_index not in range(4)
        or not isinstance(explanation, str)
        or not explanation.strip()
        or not isinstance(rationales, list)
        or len(rationales) != 4
        or not all(isinstance(reason, str) and reason.strip() for reason in rationales)
        or not isinstance(evidence, str)
        or not evidence.strip()
        or not isinstance(question_type, str)
        or question_type not in {"knowledge", "comprehension", "application", "analysis"}
    ):
        raise QuestionGenerationError(
            "The model returned an incomplete MCQ. Try again or use a different model."
        )
    normalized_source = " ".join(source_window.split()).casefold()
    normalized_evidence = " ".join(evidence.split()).casefold()
    if normalized_evidence not in normalized_source:
        raise QuestionGenerationError(
            "The model returned a source quote that could not be verified. Try again."
        )
    return {
        "question": question.strip(),
        "options": [option.strip() for option in options],
        "correct_index": correct_index,
        "explanation": explanation.strip(),
        "option_explanations": [reason.strip() for reason in rationales],
        "evidence": evidence.strip(),
        "question_type": question_type,
    }


def generate_questions(
    content: str,
    count: int,
    sample_questions: str = "",
    *,
    question_types: list[str] | None = None,
    difficulty: str = "medium",
    progress_callback: Callable[[int, int], None] | None = None,
    token_progress_callback: Callable[[int, int, int, int], None] | None = None,
) -> list[dict]:
    selected_types = question_types or ["knowledge"]
    if not selected_types or any(
        kind not in {"knowledge", "comprehension", "application", "analysis"}
        for kind in selected_types
    ):
        raise ValueError("Select one or more supported question types.")
    if difficulty not in {"low", "medium", "hard"}:
        raise ValueError("Difficulty must be low, medium, or hard.")
    contexts = _select_contexts(_windows(content), count)
    quotas = _distribute(count, len(contexts))
    generated: list[dict] = []

    for context_index, (context, quota) in enumerate(zip(contexts, quotas), start=1):
        samples = sample_questions.strip() or "No sample questions were provided."
        prompt = f"""Create exactly {quota} single-answer multiple-choice questions from the source.
Each question must have exactly four distinct options and exactly one correct option.
Use only facts supported by the source. Treat sample questions only as style references.
Difficulty: {difficulty}. Use only these question types: {", ".join(selected_types)}.
Assign each question one selected type and match the requested difficulty.
For each question, include a general explanation and a separate reason for every option,
including why the correct option is correct and why each distractor is incorrect.
Include a short verbatim quote copied exactly from the source as evidence.
Return only a JSON array with objects using these fields:
question (string), options (array of 4 strings), correct_index (integer from 0 to 3),
explanation (string), option_explanations (array of 4 strings in option order),
evidence (string), question_type (one of: {", ".join(selected_types)}).

Sample-question style references:
{samples[:4000]}

Source:
{context}
"""
        max_output_tokens = min(12_000, max(2_048, quota * 500))
        try:
            raw = chat(
                [{"role": "user", "content": prompt}],
                temperature=0.2,
                max_tokens=max_output_tokens,
                progress_callback=(
                    (
                        lambda generated: token_progress_callback(
                            context_index,
                            len(contexts),
                            generated,
                            max_output_tokens * 4,
                        )
                    )
                    if token_progress_callback is not None
                    else None
                ),
            )
        except Exception as error:
            response = getattr(error, "response", None)
            status_code = getattr(error, "status_code", None) or getattr(
                response, "status_code", None
            )
            error_code = getattr(error, "code", None)
            request_id = getattr(error, "request_id", None)
            if not request_id and response is not None:
                request_id = getattr(response, "headers", {}).get("x-request-id")
            diagnostic = " ".join(
                f"{label}={value}"
                for label, value in (
                    ("exception", type(error).__name__),
                    ("status", status_code),
                    ("code", error_code),
                    ("request_id", request_id),
                )
                if value
            )
            log.error(
                "Question model API request failed: exception=%s status=%s code=%s request_id=%s",
                type(error).__name__,
                status_code,
                error_code,
                request_id,
            )
            raise QuestionGenerationError(
                "The configured model API request failed. Check the server-side API "
                "configuration and provider availability.",
                diagnostic=diagnostic,
            ) from error
        if not raw:
            raise QuestionGenerationError(
                "The configured model returned no response. Check its API key, model, "
                "and endpoint configuration."
            )
        items = _parse_array(raw)
        if len(items) != quota:
            raise QuestionGenerationError(
                f"The model returned {len(items)} of {quota} requested questions. "
                "Try again or request fewer questions."
            )
        validated = [
            _validated_question(item, context, selected_types[0]) for item in items
        ]
        if any(item["question_type"] not in selected_types for item in validated):
            raise QuestionGenerationError(
                "The model returned a question type that was not selected. Try again."
            )
        generated.extend(validated)
        if progress_callback is not None:
            progress_callback(context_index, len(contexts))

    return generated


def public_question(question: dict) -> dict:
    return {
        "question": question["question"],
        "options": question["options"],
        "question_type": question.get("question_type", "knowledge"),
    }


def public_questions(questions: Iterable[dict]) -> list[dict]:
    return [public_question(question) for question in questions]
