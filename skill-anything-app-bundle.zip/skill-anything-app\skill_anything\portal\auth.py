"""Password and server-side session helpers for the portal."""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import os
import secrets
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, Request

from skill_anything.portal.database import connect

PASSWORD_ITERATIONS = 600_000
SESSION_DAYS = 14
SESSION_COOKIE = "skill_anything_session"


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def timestamp(value: datetime | None = None) -> str:
    return (value or utc_now()).isoformat(timespec="seconds")


def session_secret() -> bytes:
    secret = os.getenv("PORTAL_SESSION_SECRET", "")
    if len(secret) < 32:
        raise HTTPException(
            status_code=503,
            detail=(
                "Portal sessions are not configured. Set PORTAL_SESSION_SECRET to a "
                "persistent random value of at least 32 characters."
            ),
        )
    return secret.encode("utf-8")


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS
    )
    return f"pbkdf2_sha256${PASSWORD_ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored_hash: str) -> bool:
    try:
        algorithm, iterations, salt_hex, digest_hex = stored_hash.split("$")
        if algorithm != "pbkdf2_sha256":
            return False
        actual = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            bytes.fromhex(salt_hex),
            int(iterations),
        )
        return hmac.compare_digest(actual.hex(), digest_hex)
    except (ValueError, TypeError):
        return False


def keyed_hash(value: str) -> str:
    return hmac.new(session_secret(), value.encode("utf-8"), hashlib.sha256).hexdigest()


def create_session(user_id: int) -> tuple[str, str]:
    token = secrets.token_urlsafe(32)
    csrf_token = secrets.token_urlsafe(32)
    with connect() as connection:
        connection.execute(
            "INSERT INTO sessions(token_hash, user_id, csrf_token, expires_at, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (
                keyed_hash(token),
                user_id,
                csrf_token,
                timestamp(utc_now() + timedelta(days=SESSION_DAYS)),
                timestamp(),
            ),
        )
    return token, csrf_token


def current_session(request: Request, *, require_csrf: bool = False) -> dict:
    token = request.cookies.get(SESSION_COOKIE, "")
    if not token:
        raise HTTPException(status_code=401, detail="Sign in to continue.")

    token_hash = keyed_hash(token)
    with connect() as connection:
        row = connection.execute(
            """
            SELECT sessions.user_id, sessions.csrf_token, users.username
            FROM sessions JOIN users ON users.id = sessions.user_id
            WHERE sessions.token_hash = ? AND sessions.expires_at > ?
              AND users.is_active = 1
            """,
            (token_hash, timestamp()),
        ).fetchone()
    if row is None:
        raise HTTPException(status_code=401, detail="Your session expired. Please sign in again.")

    if require_csrf:
        supplied = request.headers.get("x-csrf-token", "")
        if not hmac.compare_digest(supplied, row["csrf_token"]):
            raise HTTPException(status_code=403, detail="The request could not be verified.")
    return dict(row)


def invalidate_session(request: Request) -> None:
    token = request.cookies.get(SESSION_COOKIE, "")
    if token:
        with connect() as connection:
            connection.execute(
                "DELETE FROM sessions WHERE token_hash = ?",
                (keyed_hash(token),),
            )


def client_key(request: Request) -> str:
    host = request.client.host if request.client else "unknown"
    trusted_networks = []
    for entry in os.getenv("PORTAL_TRUSTED_PROXY_NETWORKS", "").split(","):
        if entry.strip():
            try:
                trusted_networks.append(ipaddress.ip_network(entry.strip(), strict=False))
            except ValueError as error:
                raise HTTPException(
                    status_code=500,
                    detail="PORTAL_TRUSTED_PROXY_NETWORKS contains an invalid network.",
                ) from error
    try:
        peer = ipaddress.ip_address(host)
    except ValueError:
        return keyed_hash(host)
    if not any(peer in network for network in trusted_networks):
        return keyed_hash(str(peer))

    forwarded = request.headers.get("x-forwarded-for", "")
    chain = []
    for value in forwarded.split(","):
        try:
            chain.append(ipaddress.ip_address(value.strip()))
        except ValueError:
            continue
    for address in reversed([*chain, peer]):
        if any(address in network for network in trusted_networks):
            continue
        return keyed_hash(str(address))
    return keyed_hash(str(peer))
